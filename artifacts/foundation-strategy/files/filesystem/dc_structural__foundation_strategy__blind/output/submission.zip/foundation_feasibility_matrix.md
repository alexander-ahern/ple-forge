# Foundation-type feasibility and optimisation matrix - Cattail Run Data Campus Phase 1

Units: loads kips (service D+L), pressures ksf, settlement in. q_allow_net = least of Terzaghi / Meyerhof / Brinch Hansen (DM7-2 Eq 5-15, 5-14) with UFC 3-220-01 Table 2-3 FS. Settlement by layered elastic 2:1 method (RFI-019; GEC 13 Eq 5-14); improved footings by GEC 13 two-layer method (Eq 5-12, 5-13) with ns = 10. Limits: total 1.00 in; angular distortion 1/500 between adjacent units; min width 24 in (column) / 21 in (wall). Pad costs exclude rig mobilisation ($40,000/rig, charged at campus level).

## CR-P1 - Light Industrial, Public (FS 3.5), bearing depth 45 in, IMPROVED_SPREAD

Concrete: classes F1, S1, W1, C1; sulfate 0.14% -> S1 (Moderate); fc 4000 psi; max w/cm 0.5. Groundwater 8.0 ft; no dewatering.

| Tag | P D+L (k) | Type | B x L x h (in) | Stratum | q_net (ksf) | q_allow_net (ksf) T/M/H | Bearing util | Settlement (in) | Piers n / depth ft / Ra / qg psf | rho / bars | Governs | Cost (USD) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 610.0 | SPREAD | 153 x 153 x 27 | I | 3.753 | 5.144 (5.14/5.73/5.23) | 0.729 | 0.980 | - | 0.00267 / #6@6 | SETTLEMENT | 5,929 |
| F2 | 1180.0 | IMPROVED_SPREAD | 183 x 183 x 39 | I | 5.074 | 5.249 (5.32/5.88/5.25) | 0.967 | 0.721 | 16 / 8 / 0.338 / 12561 | 0.00231 / #7@6 | BEARING | 13,746 |
| F3 | 1420.0 | IMPROVED_SPREAD | 198 x 198 x 42 | I | 5.216 | 5.263 (5.41/5.95/5.26) | 0.991 | 0.765 | 19 / 8 / 0.343 / 12774 | 0.00236 / #7@6 | BEARING | 16,745 |
| F4 | 980.0 | IMPROVED_SPREAD | 168 x 168 x 33 | I | 5.000 | 5.192 (5.19/5.75/5.21) | 0.963 | 0.688 | 14 / 8 / 0.351 / 12032 | 0.00272 / #7@6 | BEARING | 11,210 |
| F5 | 520.0 | IMPROVED_SPREAD | 126 x 126 x 24 | I | 4.717 | 4.902 (4.90/5.52/5.20) | 0.962 | 0.629 | 8 / 8 / 0.356 / 11215 | 0.00290 / #6@6 | BEARING | 5,759 |
| W1 | 1650.0 | IMPROVED_SPREAD | 132 x 432 x 24 | I | 4.167 | 4.374 (4.73/4.44/4.37) | 0.952 | 0.741 | 30 / 8 / 0.372 / 9586 | 0.00339 / #7@7 | BEARING | 20,725 |

Angular distortion between adjacent units (limit 1/500 = 0.00200):

| Pair | Span (ft) | Distortion | Utilisation |
|---|---|---|---|
| F1-F2 | 24 | 0.00090 (1/1114) | 0.449 |
| F2-F3 | 20 | 0.00018 (1/5475) | 0.091 |
| F3-F4 | 16 | 0.00040 (1/2501) | 0.200 |
| F4-F5 | 12 | 0.00041 (1/2422) | 0.206 |
| F5-W1 | 5 | 0.00187 (1/535) | 0.934 |

Shear-wall footing W1 stability: sliding (0.6D+W) N = 708.0 k, H = 96.0 k, delta = 17.33 deg, base friction 221.0 k -> FS = 2.30 reported (with 1/2 passive 2.49) >= 2.0 OK; overturning (D+L+W) e = 7.80 in <= L/6 = 72.0 in (middle third) OK; uplift U = 260.0 k vs 0.6(Wf 118.8 + Ws 76.8 + D 1180.0) -> FS = 3.17 >= 1.0 OK.

Pad governing constraint: **BEARING** (max bearing utilisation 0.991; max settlement 0.979 of 1.00 in; max angular distortion 0.934 of 1/500).

Decision: **IMPROVED_SPREAD**. Spread-only alternative: $226,311 (cheapest compliant all-spread option, bearing depth 108 in). Improved alternative: $83,614 (at 45 in) + share of rig mobilisation. Adopted pad cost $83,614 (excl. mobilisation).

## CR-P2 - Light Industrial, Public (FS 3.5), bearing depth 45 in, IMPROVED_SPREAD

Concrete: classes F1, S2, W1, C1; sulfate 0.23% -> S2 (Severe); fc 4500 psi; max w/cm 0.45. Groundwater 9.0 ft; no dewatering.

| Tag | P D+L (k) | Type | B x L x h (in) | Stratum | q_net (ksf) | q_allow_net (ksf) T/M/H | Bearing util | Settlement (in) | Piers n / depth ft / Ra / qg psf | rho / bars | Governs | Cost (USD) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 646.6 | IMPROVED_SPREAD | 138 x 138 x 27 | I | 4.890 | 5.046 (5.05/5.65/5.23) | 0.969 | 0.886 | 9 / 9 / 0.334 / 12203 | 0.00272 / #7@8 | BEARING | 7,374 |
| F2 | 1250.8 | IMPROVED_SPREAD | 186 x 186 x 39 | I | 5.207 | 5.273 (5.38/5.94/5.27) | 0.987 | 0.924 | 17 / 8 / 0.347 / 12618 | 0.00246 / #7@6 | BEARING | 14,890 |
| F3 | 1505.2 | IMPROVED_SPREAD | 204 x 204 x 42 | I | 5.209 | 5.310 (5.51/6.07/5.31) | 0.981 | 0.881 | 20 / 8 / 0.340 / 12837 | 0.00252 / #8@7 | BEARING | 18,497 |
| F4 | 1038.8 | IMPROVED_SPREAD | 171 x 171 x 33 | I | 5.116 | 5.265 (5.30/5.87/5.27) | 0.972 | 0.815 | 14 / 8 / 0.338 / 12644 | 0.00290 / #7@6 | BEARING | 11,937 |
| F5 | 551.2 | IMPROVED_SPREAD | 126 x 126 x 24 | I | 5.000 | 5.009 (5.01/5.65/5.26) | 0.998 | 0.709 | 8 / 8 / 0.356 / 11888 | 0.00307 / #7@8 | BEARING | 5,934 |
| W1 | 1749.0 | IMPROVED_SPREAD | 132 x 432 x 24 | I | 4.417 | 4.465 (4.86/4.56/4.47) | 0.989 | 0.734 | 27 / 8 / 0.335 / 11008 | 0.00358 / #7@6 | BEARING | 20,703 |

Angular distortion between adjacent units (limit 1/500 = 0.00200):

| Pair | Span (ft) | Distortion | Utilisation |
|---|---|---|---|
| F1-F2 | 24 | 0.00013 (1/7684) | 0.065 |
| F2-F3 | 20 | 0.00018 (1/5704) | 0.088 |
| F3-F4 | 16 | 0.00034 (1/2900) | 0.172 |
| F4-F5 | 12 | 0.00074 (1/1358) | 0.368 |
| F5-W1 | 5 | 0.00041 (1/2424) | 0.206 |

Shear-wall footing W1 stability: sliding (0.6D+W) N = 750.5 k, H = 101.8 k, delta = 17.33 deg, base friction 234.2 k -> FS = 2.30 reported (with 1/2 passive 2.48) >= 2.0 OK; overturning (D+L+W) e = 7.80 in <= L/6 = 72.0 in (middle third) OK; uplift U = 275.6 k vs 0.6(Wf 118.8 + Ws 76.8 + D 1250.8) -> FS = 3.15 >= 1.0 OK.

Pad governing constraint: **BEARING** (max bearing utilisation 0.998; max settlement 0.923 of 1.00 in; max angular distortion 0.368 of 1/500).

Decision: **IMPROVED_SPREAD**. Spread-only alternative: $262,767 (cheapest compliant all-spread option, bearing depth 120 in). Improved alternative: $88,835 (at 45 in) + share of rig mobilisation. Adopted pad cost $88,835 (excl. mobilisation).

## CR-P3 - Light Industrial, Public (FS 3.5), bearing depth 45 in, SPREAD

Concrete: classes F1, S0, W1, C1; sulfate 0.07% -> S0 (Negligible); fc 4000 psi; max w/cm 0.5. Groundwater 19.0 ft; no dewatering.

| Tag | P D+L (k) | Type | B x L x h (in) | Stratum | q_net (ksf) | q_allow_net (ksf) T/M/H | Bearing util | Settlement (in) | Piers n / depth ft / Ra / qg psf | rho / bars | Governs | Cost (USD) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 439.2 | SPREAD | 111 x 111 x 21 | I | 5.134 | 5.264 (5.26/6.02/5.47) | 0.975 | 0.623 | - | 0.00306 / #6@6 | BEARING | 2,946 |
| F2 | 849.6 | SPREAD | 150 x 150 x 33 | I | 5.438 | 5.579 (5.77/6.49/5.58) | 0.975 | 0.850 | - | 0.00225 / #7@8 | BEARING | 6,185 |
| F3 | 1022.4 | SPREAD | 165 x 165 x 33 | I | 5.408 | 5.640 (5.97/6.68/5.64) | 0.959 | 0.978 | - | 0.00274 / #7@6 | SETTLEMENT | 7,765 |
| F4 | 705.6 | SPREAD | 138 x 138 x 27 | I | 5.336 | 5.531 (5.61/6.33/5.53) | 0.965 | 0.941 | - | 0.00288 / #7@7 | BEARING | 4,972 |
| F5 | 374.4 | SPREAD | 105 x 105 x 21 | I | 4.891 | 5.171 (5.17/5.94/5.46) | 0.946 | 0.807 | - | 0.00264 / #6@7 | BEARING | 2,585 |
| W1 | 1188.0 | SPREAD | 90 x 432 x 18 | I | 4.400 | 4.479 (4.74/4.48/4.48) | 0.982 | 0.854 | - | 0.00307 / #6@7 | BEARING | 8,192 |

Angular distortion between adjacent units (limit 1/500 = 0.00200):

| Pair | Span (ft) | Distortion | Utilisation |
|---|---|---|---|
| F1-F2 | 24 | 0.00079 (1/1268) | 0.394 |
| F2-F3 | 20 | 0.00053 (1/1879) | 0.266 |
| F3-F4 | 16 | 0.00019 (1/5263) | 0.095 |
| F4-F5 | 12 | 0.00093 (1/1072) | 0.466 |
| F5-W1 | 5 | 0.00079 (1/1268) | 0.394 |

Shear-wall footing W1 stability: sliding (0.6D+W) N = 509.8 k, H = 69.1 k, delta = 17.33 deg, base friction 159.1 k -> FS = 2.30 reported (with 1/2 passive 2.44) >= 2.0 OK; overturning (D+L+W) e = 7.45 in <= L/6 = 72.0 in (middle third) OK; uplift U = 187.2 k vs 0.6(Wf 60.8 + Ws 65.3 + D 849.6) -> FS = 3.13 >= 1.0 OK.

Pad governing constraint: **BEARING** (max bearing utilisation 0.982; max settlement 0.977 of 1.00 in; max angular distortion 0.466 of 1/500).

Decision: **SPREAD**. Spread-only alternative: $32,645 (cheapest compliant all-spread option, bearing depth 45 in). Improved alternative: $55,867 (at 42 in) + share of rig mobilisation. Adopted pad cost $32,645 (excl. mobilisation).

## CR-P4 - Apartments, Office (FS 3.0), bearing depth 45 in, IMPROVED_SPREAD

Concrete: classes F1, S1, W1, C1; sulfate 0.11% -> S1 (Moderate); fc 4000 psi; max w/cm 0.5. Groundwater 8.0 ft; no dewatering.

| Tag | P D+L (k) | Type | B x L x h (in) | Stratum | q_net (ksf) | q_allow_net (ksf) T/M/H | Bearing util | Settlement (in) | Piers n / depth ft / Ra / qg psf | rho / bars | Governs | Cost (USD) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 384.3 | SPREAD | 108 x 108 x 21 | I | 4.745 | 5.723 (5.72/6.51/6.21) | 0.829 | 0.958 | - | 0.00262 / #6@7 | SETTLEMENT | 2,716 |
| F2 | 743.4 | IMPROVED_SPREAD | 135 x 135 x 30 | I | 5.874 | 5.922 (5.92/6.63/6.16) | 0.992 | 0.646 | 9 / 8 / 0.349 / 14182 | 0.00233 / #6@6 | BEARING | 6,882 |
| F3 | 894.6 | IMPROVED_SPREAD | 147 x 147 x 30 | I | 5.962 | 6.005 (6.01/6.69/6.16) | 0.993 | 0.666 | 11 / 8 / 0.360 / 14066 | 0.00284 / #7@7 | BEARING | 8,440 |
| F4 | 617.4 | IMPROVED_SPREAD | 126 x 126 x 27 | I | 5.600 | 5.832 (5.83/6.56/6.16) | 0.960 | 0.601 | 8 / 8 / 0.356 / 13315 | 0.00240 / #6@6 | BEARING | 5,851 |
| F5 | 327.6 | IMPROVED_SPREAD | 105 x 105 x 21 | I | 4.279 | 5.663 (5.66/6.46/6.20) | 0.755 | 0.420 | 6 / 8 / 0.385 / 9589 | 0.00231 / #5@6 | ANGULAR_DISTORTION | 3,888 |
| W1 | 1039.5 | IMPROVED_SPREAD | 72 x 432 x 15 | I | 4.813 | 4.872 (5.02/4.87/5.01) | 0.988 | 0.533 | 16 / 8 / 0.364 / 11264 | 0.00323 / #5@6 | BEARING | 9,902 |

Angular distortion between adjacent units (limit 1/500 = 0.00200):

| Pair | Span (ft) | Distortion | Utilisation |
|---|---|---|---|
| F1-F2 | 24 | 0.00108 (1/924) | 0.541 |
| F2-F3 | 20 | 0.00008 (1/12267) | 0.041 |
| F3-F4 | 16 | 0.00033 (1/2987) | 0.167 |
| F4-F5 | 12 | 0.00126 (1/792) | 0.631 |
| F5-W1 | 5 | 0.00188 (1/531) | 0.942 |

Shear-wall footing W1 stability: sliding (0.6D+W) N = 446.0 k, H = 60.5 k, delta = 17.33 deg, base friction 139.2 k -> FS = 2.30 reported (with 1/2 passive 2.41) >= 2.0 OK; overturning (D+L+W) e = 7.27 in <= L/6 = 72.0 in (middle third) OK; uplift U = 163.8 k vs 0.6(Wf 40.5 + Ws 56.6 + D 743.4) -> FS = 3.08 >= 1.0 OK.

Pad governing constraint: **BEARING** (max bearing utilisation 0.993; max settlement 0.957 of 1.00 in; max angular distortion 0.942 of 1/500).

Decision: **IMPROVED_SPREAD**. Spread-only alternative: $56,815 (cheapest compliant all-spread option, bearing depth 45 in). Improved alternative: $47,178 (at 45 in) + share of rig mobilisation. Adopted pad cost $47,178 (excl. mobilisation).

## CR-P5 - Warehouse (FS 2.5), bearing depth 42 in, SPREAD

Concrete: classes F3, S0, W1, C1; sulfate 0.05% -> S0 (Negligible); fc 5000 psi; max w/cm 0.4. Groundwater 21.0 ft; no dewatering.

| Tag | P D+L (k) | Type | B x L x h (in) | Stratum | q_net (ksf) | q_allow_net (ksf) T/M/H | Bearing util | Settlement (in) | Piers n / depth ft / Ra / qg psf | rho / bars | Governs | Cost (USD) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 335.5 | SPREAD | 84 x 84 x 18 | I | 6.847 | 6.948 (6.95/8.05/7.62) | 0.985 | 0.500 | - | 0.00284 / #5@6 | BEARING | 1,668 |
| F2 | 649.0 | SPREAD | 114 x 114 x 24 | I | 7.192 | 7.498 (7.50/8.48/7.63) | 0.959 | 0.664 | - | 0.00315 / #7@7 | BEARING | 3,448 |
| F3 | 781.0 | SPREAD | 123 x 123 x 27 | I | 7.434 | 7.658 (7.66/8.63/7.66) | 0.971 | 0.770 | - | 0.00287 / #7@7 | BEARING | 4,172 |
| F4 | 539.0 | SPREAD | 105 x 105 x 21 | I | 7.040 | 7.324 (7.32/8.33/7.60) | 0.961 | 0.734 | - | 0.00345 / #6@6 | BEARING | 2,805 |
| F5 | 286.0 | SPREAD | 78 x 78 x 18 | I | 6.770 | 6.824 (6.82/7.96/7.64) | 0.992 | 0.664 | - | 0.00244 / #5@7 | BEARING | 1,429 |
| W1 | 907.5 | SPREAD | 57 x 396 x 12 | I | 5.790 | 5.890 (5.96/5.89/6.09) | 0.983 | 0.668 | - | 0.00413 / #5@6 | BEARING | 4,530 |

Angular distortion between adjacent units (limit 1/500 = 0.00200):

| Pair | Span (ft) | Distortion | Utilisation |
|---|---|---|---|
| F1-F2 | 24 | 0.00057 (1/1758) | 0.284 |
| F2-F3 | 20 | 0.00044 (1/2251) | 0.222 |
| F3-F4 | 16 | 0.00019 (1/5325) | 0.094 |
| F4-F5 | 12 | 0.00049 (1/2062) | 0.243 |
| F5-W1 | 5 | 0.00007 (1/14302) | 0.035 |

Shear-wall footing W1 stability: sliding (0.6D+W) N = 389.4 k, H = 52.8 k, delta = 17.33 deg, base friction 121.5 k -> FS = 2.30 reported (with 1/2 passive 2.38) >= 2.0 OK; overturning (D+L+W) e = 7.10 in <= L/6 = 66.0 in (middle third) OK; uplift U = 143.0 k vs 0.6(Wf 23.5 + Ws 39.2 + D 649.0) -> FS = 2.99 >= 1.0 OK.

Pad governing constraint: **BEARING** (max bearing utilisation 0.992; max settlement 0.770 of 1.00 in; max angular distortion 0.284 of 1/500).

Decision: **SPREAD**. Spread-only alternative: $18,051 (cheapest compliant all-spread option, bearing depth 42 in). Improved alternative: $36,426 (at 42 in) + share of rig mobilisation. Adopted pad cost $18,051 (excl. mobilisation).

## CR-P6 - Light Industrial, Public (FS 3.5), bearing depth 42 in, IMPROVED_SPREAD

Concrete: classes F1, S2, W1, C1; sulfate 0.26% -> S2 (Severe); fc 4500 psi; max w/cm 0.45. Groundwater 8.5 ft; no dewatering.

| Tag | P D+L (k) | Type | B x L x h (in) | Stratum | q_net (ksf) | q_allow_net (ksf) T/M/H | Bearing util | Settlement (in) | Piers n / depth ft / Ra / qg psf | rho / bars | Governs | Cost (USD) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 622.2 | IMPROVED_SPREAD | 135 x 135 x 27 | I | 4.917 | 4.933 (4.93/5.50/5.08) | 0.996 | 0.912 | 9 / 9 / 0.349 / 11870 | 0.00259 / #6@6 | BEARING | 6,980 |
| F2 | 1203.6 | IMPROVED_SPREAD | 186 x 186 x 36 | I | 5.010 | 5.140 (5.30/5.82/5.14) | 0.975 | 0.821 | 17 / 8 / 0.347 / 12142 | 0.00284 / #8@7 | BEARING | 14,460 |
| F3 | 1448.4 | IMPROVED_SPREAD | 201 x 201 x 42 | I | 5.163 | 5.179 (5.42/5.94/5.18) | 0.997 | 0.811 | 19 / 8 / 0.332 / 12933 | 0.00242 / #8@7 | BEARING | 17,467 |
| F4 | 999.6 | IMPROVED_SPREAD | 168 x 168 x 33 | I | 5.101 | 5.132 (5.21/5.75/5.13) | 0.994 | 0.726 | 14 / 8 / 0.351 / 12273 | 0.00277 / #7@6 | BEARING | 11,347 |
| F5 | 530.4 | IMPROVED_SPREAD | 126 x 126 x 24 | I | 4.811 | 4.942 (4.94/5.54/5.12) | 0.973 | 0.621 | 8 / 8 / 0.356 / 11439 | 0.00295 / #6@6 | BEARING | 5,775 |
| W1 | 1683.0 | IMPROVED_SPREAD | 132 x 432 x 24 | I | 4.250 | 4.365 (4.80/4.48/4.37) | 0.973 | 0.644 | 27 / 8 / 0.335 / 10593 | 0.00344 / #7@7 | BEARING | 20,164 |

Angular distortion between adjacent units (limit 1/500 = 0.00200):

| Pair | Span (ft) | Distortion | Utilisation |
|---|---|---|---|
| F1-F2 | 24 | 0.00032 (1/3147) | 0.159 |
| F2-F3 | 20 | 0.00004 (1/24518) | 0.020 |
| F3-F4 | 16 | 0.00044 (1/2248) | 0.222 |
| F4-F5 | 12 | 0.00073 (1/1374) | 0.364 |
| F5-W1 | 5 | 0.00038 (1/2650) | 0.189 |

Shear-wall footing W1 stability: sliding (0.6D+W) N = 722.2 k, H = 97.9 k, delta = 17.33 deg, base friction 225.4 k -> FS = 2.30 reported (with 1/2 passive 2.48) >= 2.0 OK; overturning (D+L+W) e = 7.80 in <= L/6 = 72.0 in (middle third) OK; uplift U = 265.2 k vs 0.6(Wf 118.8 + Ws 65.8 + D 1203.6) -> FS = 3.14 >= 1.0 OK.

Pad governing constraint: **BEARING** (max bearing utilisation 0.997; max settlement 0.912 of 1.00 in; max angular distortion 0.364 of 1/500).

Decision: **IMPROVED_SPREAD**. Spread-only alternative: $193,182 (cheapest compliant all-spread option, bearing depth 45 in). Improved alternative: $85,694 (at 42 in) + share of rig mobilisation. Adopted pad cost $85,694 (excl. mobilisation).

## Campus programme

Improved pads: CR-P1, CR-P2, CR-P4, CR-P6; rigs mobilised: 2 ({"RIG-1": ["CR-P1", "CR-P2"], "RIG-2": ["CR-P4", "CR-P6"]}); mobilisation $80,000; campus total $436,017.
