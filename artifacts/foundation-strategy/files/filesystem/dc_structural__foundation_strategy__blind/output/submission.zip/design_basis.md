```json
{
 "frost": {
  "afi_100yr_F_days": 556,
  "afi_product_period": "1981-2010",
  "frost_depth_in": 42,
  "superseded_product_period": "1951-1980",
  "superseded_afi_100yr_F_days": 416
 },
 "pads": {
  "CR-P1": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 226310.84,
   "improved_cost_usd": 83614.23
  },
  "CR-P2": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 262766.53,
   "improved_cost_usd": 88834.66
  },
  "CR-P3": {
   "governing_constraint": "BEARING",
   "foundation_decision": "SPREAD",
   "spread_only_cost_usd": 32645.15,
   "improved_cost_usd": 55866.91
  },
  "CR-P4": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 56815.09,
   "improved_cost_usd": 47178.18
  },
  "CR-P5": {
   "governing_constraint": "BEARING",
   "foundation_decision": "SPREAD",
   "spread_only_cost_usd": 18051.37,
   "improved_cost_usd": 36426.0
  },
  "CR-P6": {
   "governing_constraint": "BEARING",
   "foundation_decision": "IMPROVED_SPREAD",
   "spread_only_cost_usd": 193182.26,
   "improved_cost_usd": 85693.72
  }
 },
 "campus": {
  "rigs_mobilised": 2,
  "mobilisation_cost_usd": 80000.0,
  "total_cost_usd": 436017.31,
  "pads_improved": [
   "CR-P1",
   "CR-P2",
   "CR-P4",
   "CR-P6"
  ]
 },
 "rejected_criteria": [
  "UFC 3-220-01N Foundation Design (2005) - cancelled",
  "UFC 3-220-10N Soil Mechanics (2005) - cancelled",
  "AV-CR-2604 Basis of Design Rev. 1 - superseded by Rev. 3",
  "AV-CR-2604 Geotechnical Addendum 1 - superseded by Data Report Rev. 2 (incl. withdrawn 4,000 psf presumptive value)",
  "NOAA NCEI AFI return-period tables 1951-1980 - superseded edition (100-yr AFI 416 F-days)",
  "Geotechnical Data Report Rev. 2 Sec 7 presumptive 3,000 psf - preliminary only, prohibited by AHJ Amendment 4",
  "Adjacent Parcel Report Broadview Commons 2023 - different site (RFI-013)",
  "FHWA GEC 6 Shallow Foundations - written for bridges, a different class of structure",
  "EM 1110-2-2104 Table 3-1 hydraulic-structure load factors - not applicable (load combination memo)",
  "EM 1110-2-2502 Table 4-1 sliding FS 1.5 - less restrictive than UFC 3-220-01 2-4.6.3 FS 2.0",
  "Vendor (Geopier) design-manual stress concentration ratio of 20+ - rejected per RFI-011",
  "UFC 3-220-01 2-4.8.1 1.5B footing spacing - preliminary-sizing guideline, handled per RFI-017",
  "DM7-2 subgrade-reaction estimator for combined footings/mats - not the settlement method (RFI-019)"
 ]
}
```

# Design basis - Cattail Run Data Campus Phase 1 foundations (AV-CR-2604)

Structural engineer of record, Phase 1 foundation strategy: spread footings versus spread footings on rammed aggregate piers (RAP), all six pads CR-P1 to CR-P6.

## 1. Governing criteria and documents set aside

Governing criteria: UFC 3-220-01 Geotechnical Engineering (2012, Change 3, 2025) for bearing, factors of safety (Table 2-3), settlement and angular-distortion limits, minimum widths and reinforcement in thick footings (2-4.7.1, 2-4.7.7), frost (2-4.8.3, 2-4.8.4) and sliding (2-4.6.3); UFC 3-220-20 Foundations and Earth Structures (DM 7.2, 2025), the governing foundations manual, for the bearing-capacity equation (Eq 5-15), net allowable pressure (Eq 5-14), the factor tables (Tables 5-2, 5-5, 5-6, 5-8), the groundwater correction (5-3.2) and eccentricity (Eq 5-4, 5-5); FHWA GEC 13 Vol I for the aggregate-pier design (4.2.1, Eq 5-1, 5-11 to 5-14); EM 1110-2-2502 for the limit-equilibrium sliding procedure the load memo calls up; EM 1110-2-2104 (Chapter 5, by reference to ACI 318) for footing shear and flexure; UFC 3-301-01 for the thick-footing reinforcement rule; UFGS 03 30 00 (2.5.2.2, 2.5.2.3, 2.5.2.4, 2.5.2.6) for concrete durability limits; EM 1110-2-2000 Table 2-2 for the sulfate exposure condition; the owner Basis of Design Rev. 3, the AHJ letter LC-BD-26-0774 (Amendments 3 and 4), the Geotechnical Data Report Rev. 2, the laboratory summary, the Vantry grading and groundwater record, the Kettleridge proposal KGS-26-0917, the load combination memo, the RFI log and the BIM parameter standard.

Reviewed and set aside, with the reason:

* UFC 3-220-01N Foundation Design (2005) - cancelled.
* UFC 3-220-10N Soil Mechanics (2005) - cancelled.
* AV-CR-2604 Basis of Design Rev. 1 - superseded by Rev. 3.
* AV-CR-2604 Geotechnical Addendum 1 - superseded by Data Report Rev. 2 (incl. withdrawn 4,000 psf presumptive value).
* NOAA NCEI AFI return-period tables 1951-1980 - superseded edition (100-yr AFI 416 F-days).
* Geotechnical Data Report Rev. 2 Sec 7 presumptive 3,000 psf - preliminary only, prohibited by AHJ Amendment 4.
* Adjacent Parcel Report Broadview Commons 2023 - different site (RFI-013).
* FHWA GEC 6 Shallow Foundations - written for bridges, a different class of structure.
* EM 1110-2-2104 Table 3-1 hydraulic-structure load factors - not applicable (load combination memo).
* EM 1110-2-2502 Table 4-1 sliding FS 1.5 - less restrictive than UFC 3-220-01 2-4.6.3 FS 2.0.
* Vendor (Geopier) design-manual stress concentration ratio of 20+ - rejected per RFI-011.
* UFC 3-220-01 2-4.8.1 1.5B footing spacing - preliminary-sizing guideline, handled per RFI-017.
* DM7-2 subgrade-reaction estimator for combined footings/mats - not the settlement method (RFI-019).

## 2. Bearing-capacity and settlement methods; factor of safety at each pad

Bearing capacity: per UFC 3-220-01 2-4.7.1 three widely accepted methods were run for every foundation using the DM7-2 general bearing-capacity equation (Eq 5-15, drained, c = 0.25 ksf, phi = 26 deg for Stratum I): Terzaghi (1943) with Table 5-2 factors and Table 5-5 shape factors, Meyerhof (1963) with Table 5-6 shape and depth factors, and Brinch Hansen (1970) with Table 5-8 shape and depth factors. The net allowable bearing pressure is q_all,net = q_ult/FS - sigma'_zD (DM7-2 Eq 5-14) and the value reported and designed to is the LEAST of the three methods (accepted under RFI-021). The net applied pressure is q_net = P(D+L)/A (DM7-2 Eq 5-3, service D+L per the load combination memo). The groundwater correction of DM7-2 5-3.2 / Figure 5-6 is applied: the effective unit weight in the N_gamma term is averaged over the zone from the bearing level to one footing width below it using submerged weight (total - 62.4 pcf, GDR Sec 2) below the piezometer depth (Vantry record Sec 2: P1 8.0, P2 9.0, P3 19.0, P4 8.0, P5 21.0, P6 8.5 ft). At P1, P2, P4 and P6 the water table lies within B below the bearing surface and the correction reduces q_ult. No presumptive bearing value is used anywhere (AHJ Amendment 4; UFC 3-220-01 2-4.5.1 and 2-4.6.4; RFI-009).

Settlement: layered elastic compression per RFI-019 - 2V:1H stress distribution under the rectangular footing, uniform 0.25 ft layers to max(4B, 40 ft) below the bearing surface, stress at layer mid-height, s = sum(delta sigma x H / Es) (GEC 13 Eq 5-14) with the pad-specific Es of Data Report Rev. 2 and the Stratum I base interpolated linearly by station (rounded to 0.1 ft, GDR Sec 4). For improved footings the GEC 13 two-layer method is used: q_g = q ns/(ns Ra - Ra + 1) (Eq 5-12), s_uz = q_g/k_g (Eq 5-13), and the lower zone by the same layered elastic integral from the bottom of the treatment zone (Eq 5-14), s = s_uz + s_lz (Eq 5-11).

Factor of safety basis (UFC 3-220-01 Table 2-3, occupancy row from Basis of Design Rev. 3 Sec 2):

* CR-P1: Light Industrial, Public -> FS = 3.5; bearing depth 45 in in Stratum I; governing constraint BEARING.
* CR-P2: Light Industrial, Public -> FS = 3.5; bearing depth 45 in in Stratum I; governing constraint BEARING.
* CR-P3: Light Industrial, Public -> FS = 3.5; bearing depth 45 in in Stratum I; governing constraint BEARING.
* CR-P4: Apartments, Office -> FS = 3.0; bearing depth 45 in in Stratum I; governing constraint BEARING.
* CR-P5: Warehouse -> FS = 2.5; bearing depth 42 in in Stratum I; governing constraint BEARING.
* CR-P6: Light Industrial, Public -> FS = 3.5; bearing depth 42 in in Stratum I; governing constraint BEARING.

Rev. 1 of the basis of design (all buildings Warehouse, FS 2.5) is superseded and was not used. The Table 2-3 note calling for FS > 3 for super-flat warehouse floors is not invoked at CR-P5 because no such floor tolerance is specified.

## 3. Tolerable-movement criteria

Adopted: total post-construction settlement not more than 1.0 in (UFC 3-220-01 2-4.7.1, the lesser of the building-type limit and 1 in), and angular distortion between adjacent foundation units not more than 1/500 (UFC 3-220-01 2-4.7.1), checked for every adjacent pair on column line A (spans 24, 20, 16, 12 and 5 ft; the 5 ft F5-W1 pair is the tightest). Design targets were 0.98 in and 0.97 x 1/500 to keep a margin on the exact limits. Competing criteria rejected: the UFC 3-220-01 2-4.8.1 spacing of 1.5B (a preliminary-sizing guideline - per RFI-017 the units are analysed individually with no overlap reduction and will be detailed as combined footings where needed), the Broadview Commons recommendations (different site), and any looser limits from the cancelled DM 7.1/7.2 2005 volumes.

## 4. Ground-improvement design parameters and authority

* Stress concentration ratio ns = 10 - FHWA GEC 13 4.2.1 (structure foundation support under rigid footings), required by RFI-011; vendor values of 20+ rejected.
* Minimum area replacement ratio Ra >= 0.33 - FHWA GEC 13 4.2.1 (Collin 2007); Ra = n x pi x (1.25 ft)^2 / (B L) (GEC 13 Eq 5-1); provided 0.33 to 0.39, piers fitted inside the footprint at >= 3.5 ft c/c (1.0 ft clear, KGS proposal Sec 2).
* Pier diameter 30 in, treatment depth 8 to 25 ft below the soffit in whole feet, maximum top-of-pier stress 18,000 psf - Kettleridge proposal KGS-26-0917 Sec 2 (maximum q_g used 14.2 ksf).
* Stiffness modulus k_g by pad - Kettleridge proposal Sec 3 pre-production modulus tests: P1 165, P2 140, P4 195, P6 155 pci (P3 210, P5 230 not used), within the GEC 13 4.2.3.1 range of 75-360 pci.
* Settlement: GEC 13 Eq 5-11 to 5-14 (two-layer method), lower zone by the RFI-019 layered elastic procedure.
* Verification: one production modulus test per improved pad (Kettleridge Sec 5; GEC 13 4.4): 4 tests.
* Bearing on improved footings is checked conservatively with the unimproved Stratum I capacity (no bearing credit taken for the piers).

## 5. Conflicts between documents and resolution

* Frost: two NCEI AFI products give different 100-year values for LINCOLN VA USC00444909 - 1981-2010 = 556 F-days, 1951-1980 = 416 F-days. AHJ Amendment 3 and RFI-007 make the 1981-2010 product govern -> 556 > 500 F-days -> minimum bearing depth 42 in (the 1951-1980 value would have given 30 in). Governing value 42 in.
* Presumptive bearing: GDR Rev. 2 Sec 7 3,000 psf and Addendum 1 4,000 psf versus AHJ Amendment 4 / UFC 3-220-01 -> no presumptive value; site-specific analysis governs.
* Elastic moduli: Addendum 1 (320/900/2400 ksf) versus Data Report Rev. 2 per-pad values -> Rev. 2 governs.
* Occupancy / exposure: BOD Rev. 1 (Warehouse, F0) versus Rev. 3 -> Rev. 3 governs (FS 3.5/3.0/2.5; F1 or F3).
* Sliding FS: EM 1110-2-2502 Table 4-1 (1.5 usual) versus UFC 3-220-01 2-4.6.3 (2.0) -> 2.0 governs (more restrictive governing criterion). Reported FS 2.30 counts base friction only (delta = 2/3 phi = 17.3 deg on 0.6D+W); half passive would raise it to about 2.5.
* Load factors: EM 1110-2-2104 Table 3-1 hydraulic factors versus memo combinations (UFC 3-301-01 2-4.3) -> memo governs: 1.2D+1.6L for shear and flexure.
* Minimum reinforcement: BOD 0.0018 versus UFC 3-220-01 2-4.7.7 / UFC 3-301-01 0.0015 for footings over 3 ft -> 0.0018 governs everywhere (higher); No. 4 minimum bar and 12 in maximum spacing applied.
* Concrete: the most restrictive of each pad's exposure classes (UFGS 03 30 00) governs, at the lowest bid-listed strength: P1 S1 4000 psi / 0.50; P2 S2 4500 / 0.45; P3 S0 4000 / 0.50 (W1); P4 S1 4000 / 0.50; P5 S0 but F3 5000 / 0.40; P6 S2 4500 / 0.45. Sulfate condition from EM 1110-2-2000 Table 2-2 using the more severe Stratum I result (lab notes).
* Settlement method: UFC 3-220-01 refers to EM 1110-1-1904 / DM 7.1 (not available / cancelled) -> RFI-019 layered elastic method governs.
* Footing spacing 1.5B: UFC 3-220-01 2-4.8.1 versus the column grid -> RFI-017: individual units, no overlap reduction.

## 6. Shear-wall footing stability and structural design

Sliding: 0.6D+W, base friction with delta = 2/3 phi (memo), FS >= 2.0 (UFC 3-220-01 2-4.6.3). Overturning: resultant of service D+L+W inside the middle third (memo; DM7-2 Eq 5-5), with the moment taken at the soffit (M + H h). Uplift: 0.6 x (footing + soil over the projection + unfactored dead load) against the UPLIFT_W reaction (memo), FS >= 1.0. Footing shear: ACI 318 (EM 1110-2-2104 para 5.1), phi = 0.75, two-way at d/2 from the column face and one-way at d, d = h - 4 in, 1.2D+1.6L; flexure at the face of the column/wall, phi = 0.9; rho reported = max(0.0018, required As/(b d)) and placed in both directions; thickness >= 12 in on the 3-in grid.

## 7. Campus programme

* CR-P1: IMPROVED_SPREAD - spread-only $226,311 vs improved $83,614 (pad costs excluding rig mobilisation); governing BEARING.
* CR-P2: IMPROVED_SPREAD - spread-only $262,767 vs improved $88,835 (pad costs excluding rig mobilisation); governing BEARING.
* CR-P3: SPREAD - spread-only $32,645 vs improved $55,867 (pad costs excluding rig mobilisation); governing BEARING.
* CR-P4: IMPROVED_SPREAD - spread-only $56,815 vs improved $47,178 (pad costs excluding rig mobilisation); governing BEARING.
* CR-P5: SPREAD - spread-only $18,051 vs improved $36,426 (pad costs excluding rig mobilisation); governing BEARING.
* CR-P6: IMPROVED_SPREAD - spread-only $193,182 vs improved $85,694 (pad costs excluding rig mobilisation); governing BEARING.

At P1, P2 and P6 the soft Stratum I (Es 85-110 ksf) and shallow groundwater make spread-only footings meet the 1 in limit only at very large plan sizes or by going down to Stratum II at 9-10 ft, below the water table; that costs $190k-$263k per pad against $84k-$89k improved. Each of these pads saves more than $100k, far more than a $40,000 rig. P3 and P5 (Es 210 and 250 ksf) work on spread footings at the frost depth and are cheaper that way ($32.6k and $18.1k against $55.9k and $36.4k improved before mobilisation), so they are not improved. P4 saves about $9.6k when improved ($47.2k against $56.8k). On its own that would not pay for a rig, but P1, P2 and P6 already need two rigs because each rig serves at most two pads within the milestone window (KGS Sec 4), and the second rig has a free slot. Adding P4 to it costs no extra mobilisation, so the $9.6k saving is real and P4 is improved.
Programme: 4 improved pads (CR-P1, CR-P2, CR-P4, CR-P6) need ceil(4/2) = 2 rigs: RIG-1: CR-P1, CR-P2; RIG-2: CR-P4, CR-P6. Mobilisation $80,000; 4 production modulus tests; campus total $436,017. Improving a fifth pad would need a third rig ($40,000) and is uneconomic. Using one rig for only two pads would leave P6 (or P1/P2) on spread footings at a premium of more than $100k.

Bearing depths: 45 in at P1-P4 and 42 in (the frost minimum) at P5 and P6. The depth was optimised on the 3-in grid from 42 to 180 in. Depths of 48 in or more were not adopted because the open-cut side slope is triggered at 4.0 ft (Vantry Sec 3); 48 in sits right on that trigger, and the saving at 48 in is small. No excavation reaches groundwater, so no dewatering is needed.

Every pad's governing constraint is BEARING: reported q_net/q_allow,net is 0.98-1.00 on every pad, and settlement (0.77-0.98 in) and angular distortion (up to 0.94 of 1/500 at the 5 ft F5-W1 pair on P1 and P4) are also close to binding. Sliding, overturning and uplift of the shear-wall footings are not binding.
